module.exports = {
  secret: "GoNode03",
  ttl: "7d"
};
