module.exports = {
  dialect: "mysql",
  host: "127.0.0.1",
  username: "root",
  password: "123Senh@",
  database: "fastfeet",
  operatorAliases: false,
  define: {
    timestamps: true,
    underscored: true,
    underscoredAll: true
  }
};
